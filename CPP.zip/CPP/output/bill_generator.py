from reportlab.pdfgen import canvas
from datetime import datetime

# Read saved data from file
with open("bill_data.txt", "r") as f:
    guest = f.readline().strip()
    idp = f.readline().strip()
    phone = f.readline().strip()
    roomNo = f.readline().strip()
    roomType = f.readline().strip()
    price = f.readline().strip()
    days = f.readline().strip()
    total = f.readline().strip()
    paymentMode = f.readline().strip()

# Create the PDF bill
c = canvas.Canvas("bill.pdf")
c.setFont("Helvetica-Bold", 18)
c.drawString(180, 800, "Blue Moon Hotel")
c.setFont("Helvetica", 12)

c.drawString(50, 770, "----- BILL RECEIPT -----")
c.drawString(50, 740, f"Guest Name: {guest}")
c.drawString(50, 720, f"ID Proof: {idp}")
c.drawString(50, 700, f"Phone: {phone}")
c.drawString(50, 670, f"Room No: {roomNo}")
c.drawString(50, 650, f"Room Type: {roomType}")
c.drawString(50, 630, f"Price/Night: Rs.{price}")
c.drawString(50, 610, f"Days Stayed: {days}")
c.drawString(50, 580, f"Total Amount: Rs.{total}")
c.drawString(50, 560, f"Payment Mode: {paymentMode}")
c.drawString(50, 540, f"Date: {datetime.now().strftime('%d-%m-%Y %H:%M:%S')}")
c.drawString(50, 510, "Thank you for staying with us!")
c.save()
