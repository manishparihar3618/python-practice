#include <iostream>
#include <vector>
#include <string>
#include <fstream>  // ✅ Required for ofstream (file writing)
using namespace std;

//ROOM CLASS
class Room {
private:
    int roomNumber;
    string roomType;
    float pricePerNight;
    bool isAvailable;

public:
    Room(int num, string type, float price)
        : roomNumber(num), roomType(type), pricePerNight(price), isAvailable(true) {}

    bool checkAvailability() { return isAvailable; }
    void markOccupied() { isAvailable = false; }
    void markAvailable() { isAvailable = true; }

    int getRoomNumber() { return roomNumber; }
    string getRoomType() { return roomType; }
    float getPrice() { return pricePerNight; }

    void displayRoomInfo() {
        cout << "Room " << roomNumber << " | Type: " << roomType
             << " | Price/Night: " << pricePerNight
             << " | " << (isAvailable ? "Available" : "Occupied") << endl;
    }
};

//GUEST CLASS
class Guest {
private:
    string name;
    string idProof;
    string phone;
public:
    Guest(string n, string id, string p) : name(n), idProof(id), phone(p) {}

    void displayGuestInfo() {
        cout << "Guest: " << name << " | ID: " << idProof
             << " | Phone: " << phone << endl;
    }

    string getName() { return name; }
    string getId() { return idProof; }   
    string getPhone() { return phone; } 
};

//BILL PAYMENT CLASS
class BillPayment {
private:
    int billID;
    float totalAmount;
    string status;
    string paymentMode;

    Guest guest;   // store guest info
    Room* room;    // ✅ store room info
    int numDays;   // ✅ store number of days

public:
    BillPayment(int id, float amount, Guest g, Room* r, int days)
        : billID(id), totalAmount(amount), guest(g), room(r), numDays(days), status("Unpaid") {}

    void makePayment(string mode) {
        paymentMode = mode;
        status = "Paid";
        cout << "Payment of Rs." << totalAmount << " received via " << paymentMode << endl;
    }

    void displayBill() {
        cout << "\n----- BILL -----\n";
        cout << "Bill ID: " << billID << endl;
        cout << "Guest: " << guest.getName() << " | ID: " << guest.getId() 
             << " | Phone: " << guest.getPhone() << endl;
        cout << "Room " << room->getRoomNumber() << " | Type: " << room->getRoomType() 
             << " | Price/Night: " << room->getPrice() << " | Days: " << numDays << endl;
        cout << "Total Amount: " << totalAmount << endl;
        cout << "Status: " << status << endl;
        cout << "----------------\n";
    }
};

// ---------------- RESERVATION CLASS ----------------
class Reservation {
private:
    int reservationID;
    Guest guest;
    Room* room;
    int numDays;
    bool isConfirmed;
    bool checkedOut;          // ✅ New attribute to track checkout
    BillPayment* bill;

public:
    Reservation(int id, Guest g, Room* r, int days)
        : reservationID(id), guest(g), room(r), numDays(days), isConfirmed(false),
          checkedOut(false), bill(nullptr) {}

    void confirmReservation() {
        if (room->checkAvailability()) {
            room->markOccupied();
            isConfirmed = true;
            float total = room->getPrice() * numDays;
            bill = new BillPayment(reservationID * 10, total, guest, room, numDays);
            cout << "Reservation " << reservationID << " confirmed for " << guest.getName() << endl;
        } else {
            cout << "Room " << room->getRoomNumber() << " is not available!\n";
        }
    }

    void checkout(string paymentMode) {
    if (isConfirmed && bill != nullptr && !checkedOut) {
        bill->makePayment(paymentMode);
        bill->displayBill();
        room->markAvailable();    
        checkedOut = true;        

        // ✅ 1. Save bill data to a text file for Python
        ofstream out("bill_data.txt");
        out << guest.getName() << endl;
        out << guest.getId() << endl;
        out << guest.getPhone() << endl;
        out << room->getRoomNumber() << endl;
        out << room->getRoomType() << endl;
        out << room->getPrice() << endl;
        out << numDays << endl;
        out << (room->getPrice() * numDays) << endl;
        out << paymentMode << endl;
        out.close();

        // ✅ 2. Call Python script to generate PDF
        system("python bill_generator.py");   // Use "python3" on Linux
        system("start bill.pdf");  // Auto-opens PDF in default viewer on Windows

        cout << "\n✅ PDF Bill Generated Successfully (bill.pdf)\n";

        cout << guest.getName() << " checked out successfully.\n";
    } 
    else if (checkedOut) {
        cout << "Guest has already checked out!\n";
    } 
    else {
        cout << "Reservation not confirmed yet!\n";
    }
}


    void displayReservationInfo() {
        cout << "Reservation ID: " << reservationID << endl;
        guest.displayGuestInfo();
        cout << "Room " << room->getRoomNumber() 
             << " | Type: " << room->getRoomType() 
             << " | Price/Night: " << room->getPrice() 
             << " | " << (checkedOut ? "Available" : "Occupied") << endl;
        cout << "Number of Days: " << numDays << endl;
    }

    int getReservationID() { return reservationID; }
    bool isCheckedOut() { return checkedOut; }  // ✅ getter for checkedOut

    ~Reservation() { delete bill; }
};

// ---------------- STAFF CLASS ----------------
class Staff {
private:
    string name;
    int staffID;
    string role;
    float salary;

public:
    Staff(string n, int id, string r, float s) : name(n), staffID(id), role(r), salary(s) {}

    void displayStaffInfo() {
        cout << "Staff ID: " << staffID << " | Name: " << name
             << " | Role: " << role << " | Salary: " << salary << endl;
    }
};

// ---------------- HOTEL CLASS ----------------
class Hotel {
private:
    string name;
    string location;
    int totalRooms;
    float rating;
    string contact;
    string email;
    string website;

public:
    vector<Room*> rooms;         // Composition
    vector<Staff*> staffList;    // Aggregation
    vector<Reservation*> reservations; // Aggregation

    Hotel(string n, string loc, int t, float r, string c, string e, string w)
        : name(n), location(loc), totalRooms(t), rating(r), contact(c), email(e), website(w) {}

    void displayHotelInfo() {
        cout << "\n===== " << name << " =====\n";
        cout << "Location: " << location << " | Total Rooms: " << totalRooms
             << " | Rating: " << rating << endl;
        cout << "Contact: " << contact << " | Email: " << email
             << " | Website: " << website << "\n\n";
    }

    void addRoom(Room* r) { rooms.push_back(r); }
    void addStaff(Staff* s) { staffList.push_back(s); }
    void addReservation(Reservation* res) { reservations.push_back(res); }

    Room* findAvailableRoom(string type) {
        for (Room* r : rooms) {
            if (r->getRoomType() == type && r->checkAvailability())
                return r;
        }
        return nullptr;
    }

    void showAllRooms() {
        for (Room* r : rooms) r->displayRoomInfo();
    }

    void showAllStaff() {
        for (Staff* s : staffList) s->displayStaffInfo();
    }

    void showReservations() {
        for (Reservation* res : reservations) res->displayReservationInfo();
    }
};

// ---------------- MAIN ----------------
int main() {
    Hotel h("Blue Moon Hotel", "Indore", 12, 4.7, "9597843468", "hotelbluemoon123@gmail.com", "www.bluemoonhotel.com");
    h.displayHotelInfo();

    // ---------------- Add 12 Rooms ----------------
    for(int i=101;i<=112;i++){
        string type;
        float price;
        if(i<=104){ type="Single"; price=1500; }
        else if(i<=108){ type="Double"; price=2500; }
        else{ type="Family"; price=4000; }
        h.addRoom(new Room(i, type, price));
    }

    cout << "All Rooms:\n";
    h.showAllRooms();

    // ---------------- Add 10 Staff Members ----------------
    h.addStaff(new Staff("Ramesh", 1, "Manager", 40000));
    h.addStaff(new Staff("Sita", 2, "Receptionist", 20000));
    h.addStaff(new Staff("Raj", 3, "Housekeeping", 15000));
    h.addStaff(new Staff("Anita", 4, "Cook", 18000));
    h.addStaff(new Staff("Sunil", 5, "Security", 16000));
    h.addStaff(new Staff("Geeta", 6, "Receptionist", 20000));
    h.addStaff(new Staff("Deepak", 7, "Housekeeping", 15000));
    h.addStaff(new Staff("Meena", 8, "Cook", 18000));
    h.addStaff(new Staff("Kiran", 9, "Security", 16000));
    h.addStaff(new Staff("Amit", 10, "Manager", 40000));

    cout << "\nStaff List:\n";
    h.showAllStaff();

    // ---------------- Pre-made Reservations ----------------
    Guest g1("Manish", "ID101", "9876543210");
    Guest g2("Rohit", "ID102", "9876501234");
    Guest g3("Sneha", "ID103", "9876598765");

    Reservation* res1 = new Reservation(1, g1, h.findAvailableRoom("Single"), 2);
    res1->confirmReservation();
    h.addReservation(res1);

    Reservation* res2 = new Reservation(2, g2, h.findAvailableRoom("Double"), 3);
    res2->confirmReservation();
    h.addReservation(res2);

    Reservation* res3 = new Reservation(3, g3, h.findAvailableRoom("Family"), 4);
    res3->confirmReservation();
    h.addReservation(res3);

    // ---------------- Interactive Menu ----------------
    int reservationCounter = 4;
    int choice;
    do{
        cout << "\n----- HOTEL MENU -----\n";
        cout << "1. Book Room\n2. Checkout & Pay\n3. View Available Rooms\n4. View Staff\n5. View All Reservations\n6. Exit\n";
        cout << "Enter choice: "; cin >> choice;

        switch(choice){
            case 1: {
                string guestName, id, phone, roomType;
                int days;
                cout << "Enter Guest Name: "; cin >> guestName;
                cout << "Enter ID Proof: "; cin >> id;
                cout << "Enter Phone: "; cin >> phone;
                cout << "Enter Room Type (Single/Double/Family): "; cin >> roomType;
                cout << "Number of days stay: "; cin >> days;

                Guest newGuest(guestName, id, phone);
                Room* roomToBook = h.findAvailableRoom(roomType);

                if(roomToBook != nullptr){
                    Reservation* res = new Reservation(reservationCounter++, newGuest, roomToBook, days);
                    h.addReservation(res);
                    res->confirmReservation();
                    cout << "\n----- Reservation Details -----\n";
                    res->displayReservationInfo();
                } else {
                    cout << "Sorry, no rooms available of requested type.\n";
                }
                break;
            }
            case 2: {
                int resID, paymentChoice;
                cout << "Enter Reservation ID to checkout: "; cin >> resID;

                cout << "Select Payment Mode:\n1. Cash\n2. Card\n3. UPI\nEnter choice: ";
                cin >> paymentChoice;

                string paymentMode;
                switch(paymentChoice){
                case 1: paymentMode = "Cash"; break;
                case 2: paymentMode = "Card"; break;
                case 3: paymentMode = "UPI"; break;
                default: paymentMode = "Cash"; break;
            }

                bool found = false;
                for(auto res : h.reservations){
                if(resID == res->getReservationID()){
                res->checkout(paymentMode);
                found = true;
                break;    
        }
    }
                if(!found) cout << "Reservation ID not found!\n";
                break;
}

            case 3: {
                cout << "Available Rooms:\n";
                for(auto r : h.rooms){
                    if(r->checkAvailability()) r->displayRoomInfo();
                }
                break;
            }
            case 4: h.showAllStaff(); break;
            case 5: h.showReservations(); break;
            case 6: cout << "Exiting...\n"; break;
            default: cout << "Invalid choice!\n";
        }

    } while(choice != 6);

    return 0;
}
